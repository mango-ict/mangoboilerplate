# Assets
You need to provide a screenshot of your website.
This has to be in the format 800x600.