# Fonts
You need to place javascript files in here.
The MangoICT - CLI (named "mgs") will compress this folder for you.