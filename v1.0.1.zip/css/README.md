# CSS
You need to place CSS files in here.
The MangoICT - CLI (named "mgs") will compress this folder for you.